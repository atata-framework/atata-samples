# [Atata Samples](https://github.com/atata-framework/atata-samples) / JSON Configuration: Multi-Environment

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://github.com/atata-framework/atata-samples/raw/main/_archives/JsonConfiguration.MultiEnvironment.zip)

Demonstrates the way to support multiple environments using JSON configuration files.

*[Download sources](https://github.com/atata-framework/atata-samples/raw/main/_archives/JsonConfiguration.MultiEnvironment.zip), run tests, check results and experiment with [Atata Framework](https://atata.io).*
