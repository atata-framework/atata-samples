﻿namespace SampleApp.UITests;

public enum Gender
{
    Male,
    Female
}
