﻿using Atata;

[assembly: VerifyTitleSettings(Format = "{0} - Atata Sample App")]