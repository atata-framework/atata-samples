﻿namespace SampleApp.UITests;

public enum Office
{
    Berlin,
    London,
    NewYork,
    Paris,
    Rome,
    Tokio,
    Washington
}
