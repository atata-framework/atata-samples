﻿global using Atata;
global using NUnit.Framework;
global using OpenQA.Selenium;
