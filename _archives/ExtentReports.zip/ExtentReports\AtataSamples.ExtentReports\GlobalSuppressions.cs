﻿using System.Diagnostics.CodeAnalysis;

#pragma warning disable S103 // Lines should not be too long

[assembly: SuppressMessage("Critical Code Smell", "S134:Control flow statements \"if\", \"switch\", \"for\", \"foreach\", \"while\", \"do\"  and \"try\" should not be nested too deeply", Justification = "<Pending>", Scope = "member", Target = "~M:Atata.ExtentReports.ExtentLogConsumer.ResolveLogStatus(Atata.LogEventInfo)~AventStack.ExtentReports.Status")]

#pragma warning restore S103 // Lines should not be too long
