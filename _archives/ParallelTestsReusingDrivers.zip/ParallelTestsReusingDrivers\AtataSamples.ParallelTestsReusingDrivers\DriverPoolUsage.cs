﻿namespace AtataSamples.ParallelTestsReusingDrivers
{
    public enum DriverPoolUsage
    {
        None,
        Fixture,
        Global
    }
}
