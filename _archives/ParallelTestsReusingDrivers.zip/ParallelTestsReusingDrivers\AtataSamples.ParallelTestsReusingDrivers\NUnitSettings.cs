﻿using NUnit.Framework;

// LevelOfParallelism is optional here to restrict the number of parallel threads in testing purposes.
[assembly: LevelOfParallelism(3)]
