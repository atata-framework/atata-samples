﻿namespace AtataSamples.ParallelTestsReusingDrivers;

using _ = CalculationsPage;

[Url("calculations")]
public sealed class CalculationsPage : Page<_>
{
    [FindById]
    public Input<int, _> AdditionValue1 { get; private set; }

    [FindById]
    public Input<int, _> AdditionValue2 { get; private set; }

    [FindById]
    public Input<int, _> AdditionResult { get; private set; }
}
