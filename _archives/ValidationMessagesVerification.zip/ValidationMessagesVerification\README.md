# [Atata Samples](https://github.com/atata-framework/atata-samples) / Verification of Validation Messages

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://github.com/atata-framework/atata-samples/raw/master/_archives/ValidationMessagesVerification.zip)

Used in **[Verification of Validation Messages](https://atata.io/tutorials/verification-of-validation-messages/)** tutorial.

Demonstrates how to verify validation messages on web pages.

*[Download sources](https://github.com/atata-framework/atata-samples/raw/master/_archives/ValidationMessagesVerification.zip), run tests, check results and experiment with [Atata Framework](https://atata.io).*