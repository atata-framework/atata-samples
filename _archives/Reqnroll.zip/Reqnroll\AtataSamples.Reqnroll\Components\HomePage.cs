﻿namespace AtataSamples.Reqnroll.Components;

using _ = HomePage;

public sealed class HomePage : BasePage<_>
{
    public H1<_> Header { get; private set; }
}
