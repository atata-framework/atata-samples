﻿#pragma warning disable S103 // Lines should not be too long

[assembly: SuppressMessage("StyleCop.CSharp.OrderingRules", "SA1204:Static elements should appear before instance elements", Justification = "<Pending>", Scope = "member", Target = "~M:AtataSamples.Reqnroll.GlobalHooks.TearDownScenario")]
