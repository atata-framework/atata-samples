# [Atata Samples](https://github.com/atata-framework/atata-samples) / .NET Core 2.0 + NUnit

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/atata-framework/atata-samples/tree/master/NetCore.NUnit)

Demonstrates Atata usage with .NET Core 2.0 + NUnit.

*[Download sources](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/atata-framework/atata-samples/tree/master/NetCore.NUnit), run tests, check results and experiment with [Atata Framework](https://atata.io).*