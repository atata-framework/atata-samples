# [Atata Samples](https://github.com/atata-framework/atata-samples) / .NET Core 2.1 + NUnit

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://github.com/atata-framework/atata-samples/raw/master/_archives/NetCore.NUnit.zip)

Demonstrates Atata usage with .NET Core 2.1 + NUnit.

*[Download sources](https://github.com/atata-framework/atata-samples/raw/master/_archives/NetCore.NUnit.zip), run tests, check results and experiment with [Atata Framework](https://atata.io).*