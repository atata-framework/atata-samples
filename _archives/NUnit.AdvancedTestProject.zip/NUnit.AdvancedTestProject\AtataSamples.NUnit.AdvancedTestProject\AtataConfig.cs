﻿namespace AtataSamples.NUnit.AdvancedTestProject;

public sealed class AtataConfig : JsonConfig<AtataConfig>
{
    // Custom configuration properties can be added here.
    // See https://github.com/atata-framework/atata-configuration-json#custom-settings
}
