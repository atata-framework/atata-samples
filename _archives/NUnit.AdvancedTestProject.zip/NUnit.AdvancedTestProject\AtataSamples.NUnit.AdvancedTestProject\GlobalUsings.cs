﻿global using Atata;
global using Atata.Configuration.Json;
global using NUnit.Framework;
global using OpenQA.Selenium;
