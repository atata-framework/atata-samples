﻿#pragma warning disable S103 // Lines should not be too long

[assembly: SuppressMessage("Major Code Smell", "S125:Sections of code should not be commented out", Justification = "<Pending>", Scope = "member", Target = "~M:AtataSamples.JsonExtendedConfiguration.SetUpFixture.GlobalSetUp")]
