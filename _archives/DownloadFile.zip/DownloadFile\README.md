# [Atata Samples](https://github.com/atata-framework/atata-samples) / Download File

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://github.com/atata-framework/atata-samples/raw/main/_archives/DownloadFile.zip)

Demonstrates how to configure downloads directory of Chrome and verify that file is downloaded.

*[Download sources](https://github.com/atata-framework/atata-samples/raw/main/_archives/DownloadFile.zip), run tests, check results and experiment with [Atata Framework](https://atata.io).*
