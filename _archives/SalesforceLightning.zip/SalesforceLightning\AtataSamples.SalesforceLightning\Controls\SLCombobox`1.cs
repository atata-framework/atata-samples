﻿using Atata;

namespace AtataSamples.SalesforceLightning
{
    public class SLCombobox<TOwner> : SLCombobox<string, TOwner>
        where TOwner : PageObject<TOwner>
    {
    }
}
