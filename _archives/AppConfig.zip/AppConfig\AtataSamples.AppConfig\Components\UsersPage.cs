﻿namespace AtataSamples.AppConfig;

using _ = UsersPage;

public sealed class UsersPage : Page<_>
{
    public H1<_> Heading { get; private set; }
}
