﻿using Atata;

namespace AtataSamples.AppConfig;

using _ = UsersPage;

public class UsersPage : Page<_>
{
    public H1<_> Heading { get; private set; }
}
