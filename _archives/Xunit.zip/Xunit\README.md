# [Atata Samples](https://github.com/atata-framework/atata-samples) / Using Xunit

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://github.com/atata-framework/atata-samples/raw/main/_archives/Xunit.zip)

Demonstrates how to use Atata with [Xunit](https://xunit.net/) framework.

*[Download sources](https://github.com/atata-framework/atata-samples/raw/main/_archives/Xunit.zip), run tests, check results and experiment with [Atata Framework](https://atata.io).*
