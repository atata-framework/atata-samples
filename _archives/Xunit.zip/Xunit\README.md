# [Atata Samples](https://github.com/atata-framework/atata-samples) / Using Xunit

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/atata-framework/atata-samples/tree/master/Xunit)

Demonstrates how to use Atata with [Xunit](https://xunit.net/) framework.

*[Download sources](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/atata-framework/atata-samples/tree/master/Xunit), run tests, check results and experiment with [Atata Framework](https://atata.io).*