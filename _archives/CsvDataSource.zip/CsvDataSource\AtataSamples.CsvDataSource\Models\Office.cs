﻿namespace AtataSamples.CsvDataSource
{
    public enum Office
    {
        Berlin,
        London,
        NewYork,
        Paris,
        Rome,
        Tokio,
        Washington
    }
}
