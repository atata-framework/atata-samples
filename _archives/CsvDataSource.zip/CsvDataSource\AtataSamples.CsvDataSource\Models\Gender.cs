﻿namespace AtataSamples.CsvDataSource
{
    public enum Gender
    {
        Male,
        Female
    }
}
