﻿global using System.Diagnostics.CodeAnalysis;
global using Atata;
