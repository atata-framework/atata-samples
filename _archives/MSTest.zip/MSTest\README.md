# [Atata Samples](https://github.com/atata-framework/atata-samples) / Using MSTest

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://github.com/atata-framework/atata-samples/raw/main/_archives/MSTest.zip)

Demonstrates how to use Atata with MSTest.

*[Download sources](https://github.com/atata-framework/atata-samples/raw/main/_archives/MSTest.zip), run tests, check results and experiment with [Atata Framework](https://atata.io).*