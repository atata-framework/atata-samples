# [Atata Samples](https://github.com/atata-framework/atata-samples) / Using MSTest

[![Download sources](https://img.shields.io/badge/Download-sources-brightgreen.svg)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/atata-framework/atata-samples/tree/master/MSTest)

Demonstrates how to use Atata with MSTest.

*[Download sources](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/atata-framework/atata-samples/tree/master/MSTest), run tests, check results and experiment with [Atata Framework](https://atata.io).*