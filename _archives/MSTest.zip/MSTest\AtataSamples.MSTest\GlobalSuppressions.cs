﻿using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Style", "IDE0060:Remove unused parameter", Justification = "<Pending>", Scope = "member", Target = "~M:AtataSamples.MSTest.SetUpFixture.GlobalSetUp(Microsoft.VisualStudio.TestTools.UnitTesting.TestContext)")]
