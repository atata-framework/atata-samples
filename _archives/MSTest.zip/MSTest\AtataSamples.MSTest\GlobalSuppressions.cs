﻿using System.Diagnostics.CodeAnalysis;

#pragma warning disable S103 // Lines should not be too long

[assembly: SuppressMessage("Style", "IDE0060:Remove unused parameter", Justification = "<Pending>", Scope = "member", Target = "~M:AtataSamples.MSTest.SetUpFixture.GlobalSetUp(Microsoft.VisualStudio.TestTools.UnitTesting.TestContext)")]
[assembly: SuppressMessage("Usage", "CA1801:Review unused parameters", Justification = "<Pending>", Scope = "member", Target = "~M:AtataSamples.MSTest.SetUpFixture.GlobalSetUp(Microsoft.VisualStudio.TestTools.UnitTesting.TestContext)")]

#pragma warning restore S103 // Lines should not be too long
