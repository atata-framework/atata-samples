﻿[assembly: Parallelize(Scope = ExecutionScope.ClassLevel)]
