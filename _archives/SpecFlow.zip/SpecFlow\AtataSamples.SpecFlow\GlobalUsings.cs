﻿global using System.Diagnostics.CodeAnalysis;
global using Atata;
global using AtataSamples.SpecFlow.Components;
global using NUnit.Framework;
global using TechTalk.SpecFlow;
global using TechTalk.SpecFlow.Infrastructure;
