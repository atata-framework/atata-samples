﻿using Atata;

namespace AtataSamples.DevExtreme;

public class DXSelectBox<TOwner> : DXSelectBox<string, TOwner>
    where TOwner : PageObject<TOwner>
{
}
