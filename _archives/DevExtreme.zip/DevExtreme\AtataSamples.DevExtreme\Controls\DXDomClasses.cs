﻿namespace AtataSamples.DevExtreme;

public static class DXDomClasses
{
    public const string Disabled = "dx-state-disabled";

    public const string ReadOnly = "dx-state-readonly";
}
