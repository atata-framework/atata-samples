﻿using System.Diagnostics.CodeAnalysis;

#pragma warning disable S103 // Lines should not be too long

[assembly: SuppressMessage("Major Code Smell", "S103:Lines should not be too long", Justification = "<Pending>", Scope = "member", Target = "~M:AtataSamples.TableWithRowSpannedCells.FindByColumnHeaderInTableWithRowSpannedCellsStrategy.BuildXPathForCell(AtataSamples.TableWithRowSpannedCells.FindByColumnHeaderInTableWithRowSpannedCellsStrategy.ColumnInfo,System.Collections.Generic.List{AtataSamples.TableWithRowSpannedCells.FindByColumnHeaderInTableWithRowSpannedCellsStrategy.ColumnInfo})~System.String")]

#pragma warning restore S103 // Lines should not be too long
